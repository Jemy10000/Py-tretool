# tretool

## tretool - Python多功能工具库

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/)

**tretool** 是一个集成常用功能的Python工具库。

## 📦 安装

### 使用pip
bash
```pip install tretool
